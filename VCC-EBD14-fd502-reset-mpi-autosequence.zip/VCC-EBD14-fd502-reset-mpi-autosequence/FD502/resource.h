//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by fd502.rc
//
#define IDS_MODULE_NAME                 1
#define IDS_VERSION                     2
#define IDS_CATNUMBER                   3
#define IDS_DESCRIPTION                 4
#define IDD_CONFIG                      101
#define IDD_NEWDISK                     102
#define IDD_AUTOSEQUENCE                103
#define IDC_DRIVE0                      1000
#define IDC_DRIVE1                      1001
#define IDC_DRIVE2                      1002
#define IDC_EDIT1                       1003
#define IDC_EDITDRIVE0                  1003
#define IDC_PATH                        1003
#define IDC_ROMPATH                     1003
#define IDC_EDIT2                       1004
#define IDC_EDITDRIVE2                  1004
#define IDC_EDIT3                       1005
#define IDC_EDITDRIVE1                  1005
#define IDC_MOUNT                       1006
#define IDC_UNMOUNT                     1007
#define IDC_CREATE                      1008
#define IDC_TURBO                       1009
//#define IDC_KBLEDS                      1010
#define IDC_RGB                         1011
#define IDC_DMK                         1012
#define IDC_JVC                         1013
#define IDC_VDK                         1014
#define IDC_TR35                        1015
#define IDC_TR40                        1016
#define IDC_TR80                        1017
#define IDC_DBLSIDE                     1018
#define IDC_BROWSE                      1019
#define IDC_RAW                         1019
#define IDC_TEXT1                       1022
#define IDC_EXTROM                      1023
#define IDC_TRSDOS                      1024
#define IDC_PERSIST                     1028
#define IDC_DISKA                       1029
#define IDC_DISKB                       1030
#define IDC_CLOCK                       1031
#define IDC_READONLY                    1032
#define IDC_BECKER_ENAB                 1033
#define IDC_BECKER_HOST                 1034
#define IDC_BECKER_PORT                 1035
#define IDC_AS_ADDRESS                  1036
#define IDC_AS_WRAP                     1037
#define IDC_AS_PLAYLIST                 1038
#define IDC_AS_ADD                      1039
#define IDC_AS_REMOVE                   1040
#define IDC_AS_UP                       1041
#define IDC_AS_DOWN                     1042
#define IDC_AS_COUNT                    1043


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
