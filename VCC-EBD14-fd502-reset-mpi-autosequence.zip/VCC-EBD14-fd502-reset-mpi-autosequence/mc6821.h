#ifndef __MC6821_H__
#define __MC6821_H__
/*
Copyright 2015 by Joseph Forgione
This file is part of VCC (Virtual Color Computer).

    VCC (Virtual Color Computer) is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    VCC (Virtual Color Computer) is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with VCC (Virtual Color Computer).  If not, see <http://www.gnu.org/licenses/>.
*/

#include <Windows.h>

unsigned char pia0_read(unsigned char port);
void pia0_write(unsigned char data,unsigned char port);
unsigned char pia1_read(unsigned char port);
void pia1_write(unsigned char data,unsigned char port);

void ClosePrintFile();
void SetSerialParams(unsigned char);
void SetMonState(BOOL);
unsigned char VDG_Mode();
void irq_hs(int);
void irq_fs(int);
void AssertCart();
void SetCart(bool lineState);
unsigned char SetCartAutoStart(unsigned char);
void PiaReset();
unsigned char GetMuxState();
unsigned int DACState();
unsigned int GetDACSample();
unsigned char GetCasSample();
void SetCassetteSample(unsigned char);
int OpenPrintFile(const char *);
// FIXME: These need to be turned into an enum and the signature of functions
// that use them updated.
constexpr auto FALLING	= 0u;
constexpr auto RISING	= 1u;
constexpr auto ANY		= 2u;
constexpr auto RAMPMAX	= 900u;

// FIXME: These need to be turned into an enum and the signature of functions
// that use them updated.
const int PIA_MUX_DAC = 0;
const int PIA_MUX_CASSETTE = 1;
const int PIA_MUX_CARTRIDGE = 2;
const int PIA_MUX_UNUSED = 3;

#endif
