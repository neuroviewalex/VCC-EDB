////////////////////////////////////////////////////////////////////////////////
//	Copyright 2015 by Joseph Forgione
//	This file is part of VCC (Virtual Color Computer).
//	
//	VCC (Virtual Color Computer) is free software: you can redistribute itand/or
//	modify it under the terms of the GNU General Public License as published by
//	the Free Software Foundation, either version 3 of the License, or (at your
//	option) any later version.
//	
//	VCC (Virtual Color Computer) is distributed in the hope that it will be
//	useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
//	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
//	Public License for more details.
//	
//	You should have received a copy of the GNU General Public License along with
//	VCC (Virtual Color Computer). If not, see <http://www.gnu.org/licenses/>.
////////////////////////////////////////////////////////////////////////////////
#pragma once
#include <Windows.h>
#include <vcc/bus/cartridge.h>
#include <vcc/bus/cartridge_loader.h>
#include <vcc/bus/cartridge_menuitem.h>
//#include "../CartridgeMenu.h"

namespace VCC::Core
{

	class cartridge_slot
	{
	public:

		using name_type = ::VCC::Core::cartridge::name_type;
		using catalog_id_type = ::VCC::Core::cartridge::catalog_id_type;
		using description_type = ::VCC::Core::cartridge::description_type;
		using path_type = std::string;
		using label_type = std::string;
		using handle_type = ::VCC::Core::cartridge_loader_result::handle_type;
		using cartridge_ptr_type = std::unique_ptr<::VCC::Core::cartridge>;
		using callbacks_type = ::VCC::Core::cartridge_callbacks;

	public:

		cartridge_slot();
		cartridge_slot(path_type path, handle_type handle, cartridge_ptr_type cartridge);
		cartridge_slot(const cartridge_slot&) = delete;
		cartridge_slot(cartridge_slot&&) = delete;

		cartridge_slot& operator=(const cartridge_slot& other) = delete;
		cartridge_slot& operator=(cartridge_slot&& other) noexcept;

		bool empty() const
		{
			return path_.empty();
		}

		const path_type& path() const
		{
			return path_;
		}

		name_type name() const
		{
			return cartridge_->name();
		}

		catalog_id_type catalog_id() const
		{
			return cartridge_->catalog_id();
		}

		description_type description() const
		{
			return cartridge_->description();
		}

		label_type label() const;

		void start() const
		{
			cartridge_->start();
		}

		void stop() const
		{
			cartridge_->stop();
		}

		void set_window_handle(HWND hVccWnd) const;
		void cpu_memory_write(unsigned char value, unsigned short address) const;
		bool cpu_memory_read(unsigned short address, unsigned char* value) const;

		void reset() const
		{
			cartridge_->reset();
		}

		void process_horizontal_sync() const
		{
			cartridge_->process_horizontal_sync();
		}

		void write_port(unsigned char port_id, unsigned char value) const
		{
			cartridge_->write_port(port_id, value);
		}

		unsigned char read_port(unsigned char port_id) const
		{
			return cartridge_->read_port(port_id);
		}

		unsigned char read_memory_byte(unsigned short memory_address) const
		{
			return cartridge_->read_memory_byte(memory_address);
		}

		void status(char* text_buffer, size_t buffer_size) const
		{
			cartridge_->status(text_buffer, buffer_size);
		}

		unsigned short sample_audio() const
		{
			return cartridge_->sample_audio();
		}

		void menu_item_clicked(unsigned char item_id) const
		{
			return cartridge_->menu_item_clicked(item_id);
		}

		void line_state(bool state)
		{
			line_state_ = state;
		}

		bool line_state() const
		{
			return line_state_;
		}

		bool get_menu_item(menu_item_entry* item, size_t index)
		{
			return cartridge_->get_menu_item(item, index);
		}

	private:

		path_type path_;
		handle_type handle_;
		cartridge_ptr_type cartridge_;
		bool line_state_ = false;
	};

}
