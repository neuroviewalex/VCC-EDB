//#define USE_LOGGING
//======================================================================
// This file is part of VCC (Virtual Color Computer).
// Vcc is Copyright 2015 by Joseph Forgione
//
// VCC (Virtual Color Computer) is free software, you can redistribute
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation, either version 3 of
// the License, or (at your option) any later version.
//
// VCC (Virtual Color Computer) is distributed in the hope that it will
// be useful, but WITHOUT ANY WARRANTY; without even the implied
// warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with VCC (Virtual Color Computer).  If not, see
// <http://www.gnu.org/licenses/>.
//======================================================================

#include "defines.h"
#include "tcc1014mmu.h"
#include "tcc1014registers.h"
#include "pakinterface.h"
#include "config.h"
#include "Vcc.h"
#include "mc6821.h"
#include "resource.h"
#include <vcc/bus/null_cartridge.h>
#include <vcc/bus/cpak_cartridge.h>
#include <vcc/bus/cartridge_menu.h>
#include <vcc/bus/cartridge_messages.h>
#include <vcc/bus/dll_deleter.h>
#include <vcc/util/limits.h>
//#include <vcc/util/winapi.h>
#include <vcc/util/logger.h>
#include <vcc/util/FileOps.h>
#include <vcc/util/DialogOps.h>
#include <fstream>
#include <atomic>
#include <Windows.h>
#include <commdlg.h>

using cartridge_loader_status = VCC::Core::cartridge_loader_status;
using cartridge_loader_result = VCC::Core::cartridge_loader_result;

// Storage for Pak ROMs
extern SystemState EmuState;

static VCC::Util::critical_section gPakMutex;
static char DllPath[MAX_PATH] = "";
static cartridge_loader_result::handle_type gActiveModule;
static cartridge_loader_result::cartridge_ptr_type gActiveCartrige(std::make_unique<VCC::Core::null_cartridge>());
static std::atomic<unsigned int> gCpuWriteWatchAddress[5]{};
static std::atomic<bool> gCpuWriteWatchEnabled[5]{};
// One exact-address fast path keeps ordinary CPU memory reads cheap when no
// cartridge has an active readback register.
static std::atomic<unsigned int> gCpuMemoryReadWatchAddress{0x10000};

static void RefreshCpuMemoryReadWatchAddress()
{
	unsigned int read_address = 0x10000;
	for (size_t slot = 0; slot < 5; ++slot)
	{
		if (!gCpuWriteWatchEnabled[slot].load(std::memory_order_acquire))
			continue;
		const unsigned int base = gCpuWriteWatchAddress[slot].load(std::memory_order_relaxed);
		if (base < 0xFFFF)
		{
			read_address = base + 1;
			break;
		}
	}
	gCpuMemoryReadWatchAddress.store(read_address, std::memory_order_release);
}

static void PakSetCpuMemoryWriteWatch(slot_id_type SlotId, unsigned short address, bool enabled)
{
	if (SlotId >= 5) return;
	gCpuWriteWatchAddress[SlotId].store(address, std::memory_order_relaxed);
	gCpuWriteWatchEnabled[SlotId].store(enabled, std::memory_order_release);
	RefreshCpuMemoryReadWatchAddress();
}

static bool IsPakAutoRegisterAddress(unsigned short base, unsigned short address)
{
	// Preserve the original two-byte command/readback ABI.
	return base < 0xFFFF &&
		(address == base || address == static_cast<unsigned short>(base + 1));
}

bool PakCpuMemoryWriteIsWatched(unsigned short address)
{
	for (size_t slot = 0; slot < 5; ++slot)
	{
		if (gCpuWriteWatchEnabled[slot].load(std::memory_order_acquire) &&
			IsPakAutoRegisterAddress(
				static_cast<unsigned short>(gCpuWriteWatchAddress[slot].load(std::memory_order_relaxed)),
				address))
			return true;
	}
	return false;
}

bool PakCpuMemoryReadIsWatched(unsigned short address)
{
	return gCpuMemoryReadWatchAddress.load(std::memory_order_acquire) ==
		static_cast<unsigned int>(address);
}

void PakCpuMemoryWrite(unsigned char value, unsigned short address)
{
	if (!PakCpuMemoryWriteIsWatched(address)) return;

	VCC::Util::section_locker lock(gPakMutex);
	gActiveCartrige->cpu_memory_write(value, address);
}

bool PakCpuMemoryRead(unsigned short address, unsigned char* value)
{
	if (!value || !PakCpuMemoryReadIsWatched(address))
		return false;

	VCC::Util::section_locker lock(gPakMutex);
	return gActiveCartrige->cpu_memory_read(address, value);
}

static cartridge_loader_status load_any_cartridge(const char* filename, const char* iniPath);

void CartMenuCallBack(const char* name, int menu_id, MenuItemType type);
void PakAssertInterupt(Interrupt interrupt, InterruptSource source);


struct vcc_cartridge_callbacks : public ::VCC::Core::cartridge_callbacks
{

	path_type configuration_path() const override
	{
		char path_buffer[MAX_PATH];

		GetIniFilePath(path_buffer);

		return path_buffer;
	}

	void write_memory_byte(unsigned char value, unsigned short address) override
	{
		MemWrite8(value, address);
	}

	unsigned char read_memory_byte(unsigned short address) override
	{
		return MemRead8(address);
	}

	void assert_cartridge_line(bool line_state) override
	{
		SetCart(line_state);
	}

	void assert_interrupt(Interrupt interrupt, InterruptSource interrupt_source) override
	{
		PakAssertInterupt(interrupt, interrupt_source);
	}

};

static void PakAssertCartrigeLine(slot_id_type /*SlotId*/, bool line_state)
{
	SetCart(line_state);
}

static void PakWriteMemoryByte(slot_id_type /*SlotId*/, unsigned char data, unsigned short address)
{
	MemWrite8(data, address);
}

static unsigned char PakReadMemoryByte(slot_id_type /*SlotId*/, unsigned short address)
{
	return MemRead8(address);
}

static void PakAssertInterupt(slot_id_type /*SlotId*/, Interrupt interrupt, InterruptSource source)
{
	PakAssertInterupt(interrupt, source);
}

void PakTimer()
{
	VCC::Util::section_locker lock(gPakMutex);

	gActiveCartrige->process_horizontal_sync();
}

void ResetBus()
{
	VCC::Util::section_locker lock(gPakMutex);

	gActiveCartrige->reset();
}

// Refresh the active PAK after CreateDDWindow recreates VCC's main HWND.
void RefreshPakWindowHandle()
{
	VCC::Util::section_locker lock(gPakMutex);

	if (auto* cpak = dynamic_cast<VCC::Core::cpak_cartridge*>(gActiveCartrige.get()))
		cpak->set_window_handle(EmuState.WindowHandle);
}

void GetModuleStatus(SystemState *SMState)
{
	VCC::Util::section_locker lock(gPakMutex);

	gActiveCartrige->status(SMState->StatusLine, sizeof(SMState->StatusLine));
}

unsigned char PakReadPort (unsigned char port)
{
	VCC::Util::section_locker lock(gPakMutex);

	return gActiveCartrige->read_port(port);
}

void PakWritePort(unsigned char Port,unsigned char Data)
{
	VCC::Util::section_locker lock(gPakMutex);

	gActiveCartrige->write_port(Port,Data);
}

unsigned char PackMem8Read (unsigned short Address)
{
	VCC::Util::section_locker lock(gPakMutex);

	return gActiveCartrige->read_memory_byte(Address&32767);
}

// Convert PAK interrupt assert to CPU assert or Gime assert.
void PakAssertInterupt(Interrupt interrupt, InterruptSource source)
{
	(void) source; // not used

	switch (interrupt) {
	case INT_CART:
		GimeAssertCartInterupt();
		break;
	case INT_NMI:
		CPUAssertInterupt(IS_NMI, INT_NMI);
		break;
	}
}

unsigned short PackAudioSample()
{
	VCC::Util::section_locker lock(gPakMutex);

	return gActiveCartrige->sample_audio();
}

// Build entries for cartridge menu.
void BuildCartMenu()
{
	//VCC::Util::section_locker lock(gPakMutex);
	using VCC::Bus::gVccCartMenu;
	gVccCartMenu.clear();
	if (!gActiveCartrige->name().empty()) {
		std::string tmp = "&Eject " + gActiveCartrige->name();
		gVccCartMenu.add(tmp, ControlId(2), MIT_StandAlone);
		// Add items from loaded pak
		menu_item_entry item;
		for (size_t index=0;index<MAX_MENU_ITEMS;index++) {
			if (gActiveCartrige->get_menu_item(&item,index)) {
				gVccCartMenu.add(item.name,item.menu_id,item.type);
			} else {
				break;
			}
		}
	} else {
		gVccCartMenu.add("Load &MPI", ControlId(3), MIT_StandAlone);
		gVccCartMenu.add("Load &DLL", ControlId(1), MIT_StandAlone);
		gVccCartMenu.add("Load &ROM", ControlId(4), MIT_StandAlone);
	}
}

void PakLoadCartridgeUI(int type)
{
	char inifile[MAX_PATH];
	GetIniFilePath(inifile);

	static char cartDir[MAX_PATH] = "";
	FileDialog dlg;
	if (type == 0) {
		dlg.setTitle(TEXT("Load Program Pack"));
		dlg.setFilter("Hardware Packs\0*.dll\0"
				"All Supported Formats (*.dll;*.ccc;*.rom)\0*.dll;*.ccc;*.rom\0\0");
		Setting().read("DefaultPaths", "DLLPath", "", cartDir, MAX_PATH);
	} else {
		dlg.setTitle(TEXT("Load ROM"));
		dlg.setFilter("Rom Packs(*.ccc;*.rom)\0*.ccc;*.rom\0"
				"All Supported Formats (*.dll;*.ccc;*.rom)\0*.dll;*.ccc;*.rom\0\0");
		Setting().read("DefaultPaths", "RomPath", "", cartDir, MAX_PATH);
	}
	dlg.setInitialDir(cartDir);
	dlg.setFlags(OFN_FILEMUSTEXIST);
	if (dlg.show()) {
		auto status = PakLoadCartridge(dlg.path());
		if (status == cartridge_loader_status::success) {
			char filetype[4];
			dlg.getdir(cartDir);
			dlg.gettype(filetype);
			if ((strcmp(filetype,"dll") == 0) | (strcmp(filetype,"DLL") == 0 )) {  // DLL?
				Setting().write("DefaultPaths", "DLLPath", cartDir);
			} else {
				Setting().write("DefaultPaths", "RomPath", cartDir);
			}
		}
	}
}

cartridge_loader_status PakLoadCartridge(const char* filename)
{
	static const std::map<cartridge_loader_status, UINT> string_id_map = {
		{ cartridge_loader_status::already_loaded, IDS_MODULE_ALREADY_LOADED},
		{ cartridge_loader_status::cannot_open, IDS_MODULE_CANNOT_OPEN},
		{ cartridge_loader_status::not_found, IDS_MODULE_NOT_FOUND },
		{ cartridge_loader_status::not_loaded, IDS_MODULE_NOT_LOADED },
		{ cartridge_loader_status::not_rom, IDS_MODULE_NOT_ROM },
		{ cartridge_loader_status::not_expansion, IDS_MODULE_NOT_EXPANSION }
	};

	char TempIni[MAX_PATH]="";
	GetIniFilePath(TempIni);

	const auto result(load_any_cartridge(filename, TempIni));
	if (result == cartridge_loader_status::success)
	{
		Setting().write("Module", "OnBoot", filename);
		return result;
	}

    // Tell user why load failed
	auto error_string(VCC::Core::cartridge_load_error_string(result));
	error_string += "\n\n";
	error_string += filename;
	MessageBox(EmuState.WindowHandle, error_string.c_str(), "Load Error", MB_OK | MB_ICONERROR);

	return result;
}

// Insert Module returns 0 on success
static cartridge_loader_status load_any_cartridge(const char *filename, const char* iniPath)
{
	cpak_callbacks callbacks {
		PakAssertInterupt,
		PakAssertCartrigeLine,
		PakWriteMemoryByte,
		PakReadMemoryByte,
		PakSetCpuMemoryWriteWatch
	};

	slot_id_type SlotId = 0;

	// pakinterface slot adapter only needs callbacks structure
	auto boot_slot_adapter=std::make_unique<vcc_cartridge_callbacks>();

	// SlotId, iniPath, WindowHandle, and callbacks are unused for ROM carts
	auto loadedCartridge = VCC::Core::load_cartridge(
		filename,
		std::move(boot_slot_adapter),
		SlotId, 
		iniPath,
		EmuState.WindowHandle,
		callbacks);

	if (loadedCartridge.load_result != cartridge_loader_status::success)
	{
		return loadedCartridge.load_result;
	}

	DLOG_C("pakinterface:load_any_cartridge type: %s cart ptr: %p\n",
			typeid(*loadedCartridge.cartridge.get()).name(),
			loadedCartridge.cartridge.get());

	// unload active cartridge (UnloadDLL() is poorly named but is called from Vcc.cpp)
	UnloadDll();

	VCC::Util::section_locker lock(gPakMutex);

	strcpy(DllPath, filename);
	gActiveCartrige = move(loadedCartridge.cartridge);
	gActiveModule = move(loadedCartridge.handle);
	SendMessage(EmuState.WindowHandle,WM_VCC_UPD_MENU,(WPARAM) 0,(LPARAM) 0);

	// initialize the cartridge and reset the CPU *now*
	gActiveCartrige->start();
	EmuState.ResetPending = 2;

	return loadedCartridge.load_result;
}

// TODO: Rename this to UnloadCartridge() because it handles ROM carts as well as DLL's
void UnloadDll()
{
	VCC::Util::section_locker lock(gPakMutex);

	// gActiveCartrige is one of a ROM, DLL, or NULL cartridge
	gActiveCartrige->stop();

	gActiveCartrige = std::make_unique<VCC::Core::null_cartridge>();
	gActiveModule.reset();

	SendMessage(EmuState.WindowHandle,WM_VCC_UPD_MENU,(WPARAM) 0,(LPARAM) 0);
	gActiveCartrige->start();
}

void GetCurrentModule(char *DefaultModule)
{
	strcpy(DefaultModule,DllPath);
	return;
}

void UpdateBusPointer()
{
	// Do nothing for now. What the plan was for this is unknown.
}

void UnloadPack()
{
	UnloadDll();
	strcpy(DllPath,"");
	SetCart(0);
	EmuState.ResetPending=2;

	char inifile[MAX_PATH];
	GetIniFilePath(inifile);
	Setting().delete_key("Module", "OnBoot");
}

void LoadPack(int type) {
    PakLoadCartridgeUI(type);
	EmuState.ResetPending=2;
}

// CartMenuActivated is called from VCC main when a cartridge menu item is clicked.
void CartMenuActivated(unsigned int MenuID)
{
	switch (MenuID)
	{
	case 1:
		LoadPack(0);
		return;

	case 2:
		UnloadPack();
		return;

	case 3:
	{
		char path[MAX_PATH];
		GetModuleFileName(nullptr,path,MAX_PATH);
		PathRemoveFileSpec(path);
		strncat(path,"mpi.dll",MAX_PATH);
		PakLoadCartridge(path);
		return;
    }
	case 4:
		LoadPack(1);
		return;

	default:
		break;
	}

	VCC::Util::section_locker lock(gPakMutex);

	// menu_item_clicked takes unsigned char. This limits total number of menu items
	// to 255. 50 are allocated to host cart and 50 each to mpi carts for 250 total.
	// This should be more than enough for future needs.

	unsigned char menu_item = MenuID & 0xFF;
	gActiveCartrige->menu_item_clicked(menu_item);
}
