// license:BSD-3-Clause
// copyright-holders:Nicola Salmoria
#pragma once
#include <cstdint>


class SN76489Device
{
public:

	using stream_sample_t = unsigned short;

	SN76489Device() = default;
	virtual ~SN76489Device() = default;

	virtual void device_start();
	virtual void write(uint8_t data);
	virtual stream_sample_t sound_stream_update(stream_sample_t &lbuffer, stream_sample_t &rbuffer);


protected:



private:

	inline bool     in_noise_mode() const;
	void            countdown_cycles();


	const int32_t	m_feedback_mask = 0x4000;	// mask for feedback
	const int32_t	m_whitenoise_tap1 = 0x01;	// mask for white noise tap 1 (higher one, usually bit 14)
	const int32_t	m_whitenoise_tap2 = 0x02;	// mask for white noise tap 2 (lower one, usually bit 13)
	const bool		m_negate = false;			// output negate flag
	const bool		m_stereo = false;			// whether we're dealing with stereo or not
	const float		m_period_divider = 6.11f;	// period divider
	const bool		m_ncr_style_psg = false;	// flag to ignore writes to regs 1,3,5,6,7 with bit 7 low
	const bool		m_sega_style_psg = true;	// flag to make frequency zero acts as if it is one more than max (0x3ff+1) or if it acts like 0; the initial register is pointing to 0x3 instead of 0x0; the volume reg is preloaded with 0xF instead of 0x0

	int32_t         m_vol_table[16] = { 0 };	// volume table (for 4-bit to db conversion)

	bool            m_ready_state = false;
	int32_t         m_cycles_to_ready = 0;	// number of cycles until the READY line goes active
	int32_t         m_register[8] = { 0 };	// registers
	int32_t         m_last_register = 0;	// last register written
	uint32_t        m_RNG = 0;				// noise generator LFSR
	int32_t         m_stereo_mask = 0;		// the stereo output mask
	int32_t         m_period[4] = { 0 };	// Length of 1/2 of waveform
	int32_t         m_volume[4] = { 0 };	// db volume of voice 0-2 and noise
	int32_t         m_count[4] = { 0 };		// Position within the waveform
	int32_t         m_output[4] = { 0 };	// 1-bit output of each channel, pre-volume
};
