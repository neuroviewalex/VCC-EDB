//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GMC.rc
//
#define IDS_MODULE_NAME                 1
#define IDS_CATNUMBER                   2
#define IDS_DESCRIPTION                 3
#define IDS_VERSION                     4

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
